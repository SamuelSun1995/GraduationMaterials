# Paper - Single Image Haze Removal Using Dark Channel Prior, 论文复现 - 基于暗通道先验的图像去雾算法

###  Reference Paper：
Single Image Haze Removal Using Dark Channel Prior - Kaiming He, Jian Sun, and Xiaoou Tang, Fellow, IEEE.

### Algorithm demonstration：
![Alt text](https://github.com/CHENG-MING/Single-Image-Haze-Removal-Using-Dark-Channel-Prior/raw/master/Test_picture/Demo.jpg)

### Requirements:
	* Matlab toolsbox
